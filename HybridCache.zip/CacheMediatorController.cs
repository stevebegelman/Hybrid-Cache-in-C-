using Asp.Versioning;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using CacheAggregator.Application.Features;

using AutoMapper;
using CacheAggregator.Application.Contracts.Persistence;
using Microsoft.Extensions.Caching.Hybrid;

using static Slapper.AutoMapper;

using CacheAggregator.Domain.Entities;
using Serilog.Core;
using Serilog;

using System.Collections.Generic;
using CacheAggregator.Application.Features.Products.Queries;
using CacheAggregator.Domain.Common;

namespace CacheAggregator.Api.Controllers.V1
{
    /// <summary>
    /// CacheMediatorController
    /// </summary>
    /// <response code="401">Not Authenticated</response>
    [ApiController]
    [Route("api/v{version:apiVersion}/cachemediator")]
    [ApiVersion("1.0")]
    [Consumes("application/json")]
    [Produces("application/json")]
    //[Authorize]
    [AllowAnonymous]
    public class CacheMediatorController : ODataController, ICacheMediatorController
    {
        private readonly IConfiguration _configuration;
        private readonly IMediator _mediator;

        /// <summary>
        /// Continent Controller Constructor
        /// </summary>
        /// <param name="mediator"></param>
        public CacheMediatorController(IConfiguration configuration, IMediator mediator)
        {
            _configuration = configuration;
            _mediator = mediator;
        }

        /// <summary>
        ///  Read One Product Id from Cache -> L1/L2/L3/L4
        /// </summary>
        [HttpGet("GetProductById")]
        [Produces("application/json")]
        public async Task<ProductEntity> GetProductById(string _cacheKey)   // Read  one key data in cache -> L1/L2/L3
        {
            var response = await _mediator.Send(new GetProductByIdQuery
            {
                id = _cacheKey,
                token = CancellationToken.None
            });
            return response;
        }

        /// <summary>
        ///  Read all Products data in Cache -> L1/L2/L3/L4
        /// </summary>
        [HttpGet("GetAllProducts")]
        [Produces("application/json")]
        [EnableQuery()]   // for OData
        public async Task<List<ProductEntity>> GetAllProducts()   // Read all Products data in Cache -> L1/L2/L3
        {
            var response = await _mediator.Send(new GetAllProductsQuery
            {
                token = CancellationToken.None
            });
            return response;
        }
        /// <summary>
        /// Simulate Product Data Creation from MQ-Series for Cache Initialisation [Mock]
        /// </summary>
        /// <returns>Returns a <see cref="IQueryable"/> deffered instance for OData querying.</returns>
        [HttpGet("CreateInitialCacheData")]
        [Produces("application/json")]
        public async Task<List<ProductEntity>> CreateInitialCacheData()
        {
            var response = await _mediator.Send(new CreateInitialCacheDataQuery
            {
                nbrLines = 20
            });
            return response;
        }

        /// <summary>
        ///  Push raw Memory 'ProductEntity' data to Cache
        /// </summary>
        /// <returns>Returns a <see cref="IQueryable"/> defered instance for OData querying.</returns>
        [HttpGet("PushInitialProductDataToCache")]
        [Route("")]
        public async Task<bool> PushInitialProductDataToCache()
        {
            var response = await _mediator.Send(new CreateInitialCacheDataQuery
            {
                nbrLines = 20
            });

            var results = await _mediator.Send(new PushInitialProductDataToCacheQuery
            {
                productData = response
            });
            return results;
        }

        /// <summary>
        /// Add One New ProductEntity to Cache
        /// </summary>
        [HttpPost("AddProductToCache")]
        [Produces("application/json")]
        public async Task<bool> AddProductToCache(ProductEntity product)   // Add one new Product Entity to Cache
        {
            var response = await _mediator.Send(new AddProductToCacheQuery
            {
                productData = product
            });
            return response;
        }

        /// <summary>
        /// Add a Generic Entity to Cache
        /// </summary>
        [HttpPost("AddEntityToCache")]
        [Produces("application/json")]
        public async Task<bool> AddEntityToCache<T> ([FromBody]T myEntity ) where T : class  // Add one new Generic Entity to Cache
        {
            var response = await _mediator.Send(new AddEntityToCacheQuery
            {
                objectData = myEntity
            });
            return response;
        }

        /// <summary>
        ///  Remove an Item  from Cache
        /// </summary>
        [HttpPost("RemoveItemFromCache")]
        [Produces("application/json")]
        public async Task<bool> RemoveItemFromCache(string Name, string Id)   // Remove Entity from Cache
        {
            var response = await _mediator.Send(new RemoveItemFromCacheQuery
            {
                name = Name,
                id = Id,
            });
            return response;
        }

        /// <summary>
        ///  Get Execution Stats on this Cache
        /// </summary>
        [HttpGet("GetStats")]
        [Produces("application/json")]
        public async Task<string> GetStats()   // GetStats Hit & Miss
        {
            var response = await _mediator.Send(new GetStatsQuery
            {

            });
            return response;
        }

    }
}


