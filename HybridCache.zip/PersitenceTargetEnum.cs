﻿namespace CacheAggregator.Api
{
    /// <summary>
    /// Persistence target enumeration
    /// </summary>
    public enum PersistenceTarget
    {
        /// <summary>
        /// Azure Table storage is cibled.
        /// </summary>
        AzureTableStorage = 0,

        /// <summary>
        /// SQL Server coupled with Entity Framework storage is cibled.
        /// </summary>
        SqlServerViaEntityFramework,

        /// <summary>
        /// SQL Server coupled with Dapper Framework storage is cibled.
        /// </summary>
        SqlServerViaDapper,
    }
}
