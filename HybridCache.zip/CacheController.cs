using Asp.Versioning;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using CacheAggregator.Application.Features;

using AutoMapper;
using CacheAggregator.Application.Contracts.Persistence;
using Microsoft.Extensions.Caching.Hybrid;

using static Slapper.AutoMapper;

using CacheAggregator.Domain.Entities;
using Serilog.Core;
using Serilog;

using System.Collections.Generic;

namespace CacheAggregator.Api.Controllers.V1
{
    /// <summary>
    /// Continent Controller
    /// </summary>
    /// <response code="401">Not Authenticated</response>
    [ApiController]
    [Route("api/v{version:apiVersion}/cache")]
    [ApiVersion("1.0")]
    [Consumes("application/json")]
    [Produces("application/json")]
    //[Authorize]             Uncomment to Activate Security
    [AllowAnonymous]
    public class CacheController : ODataController
    {
        private readonly IConfiguration _configuration;
        private readonly IMediator _mediator;
        private readonly HybridCache _cache;
        private readonly IProductRepository _productRepository;
        private readonly AppDbContext _appDbContext;

        /// <summary>
        /// Continent Controller Constructor
        /// </summary>
        /// <param name="mediator"></param>
        public CacheController(IConfiguration configuration,
                               IMediator mediator,
                               HybridCache cache,
                               IProductRepository repository, 
                               AppDbContext appDbContext
                              )
        {
            _configuration = configuration;
            _mediator = mediator;
            _cache = cache;
            _productRepository = repository;
            _appDbContext = appDbContext;
        }


        /// <summary>
        /// Simulate Product Data Creation from MQ-Series for Cache Initialisation [Mock]
        /// </summary>
        /// <returns>Returns a <see cref="IQueryable"/> deffered instance for OData querying.</returns>
        [HttpGet("CreateInitialCacheData")]
        [Route( "")]
        //[ProducesResponseType(StatusCodes.Status200OK, Type = typeof(ProductEntityDto))]
        //[ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<List<ProductEntity>> CreateInitialCachedData(int nbrLines)   // Raw Data in Memory Only
        {
            List<ProductEntity> results = await _productRepository.CreateInitialCacheData(nbrLines);   
            // var response = await _mediator.Send(new CreateInitialHybridCacheData();
            return results;
        }

        /// <summary>
        ///  Push raw Memory 'Product-Type' data to Cache
        /// </summary>
        /// <returns>Returns a <see cref="IQueryable"/> defered instance for OData querying.</returns>
        [HttpGet("PushInitialDataToCache")]
        [Route("")]
        public async Task<bool> PushInitialProductDataToCache()   
        {
            ProductServiceHybrid _productRepository = new ProductServiceHybrid(_appDbContext, _cache);
            Task<List<ProductEntity>> _entities = CreateInitialCachedData(25);
            bool results = await _productRepository.PushInitialProductDataToCache( _entities.Result, _cache);
            // var response = await _mediator.Send(new CreateInitialHybridCacheData();
            return results;
        }

        /// <summary>
        ///  Read all Product data in Cache -> L1/L2/L3/L4
        /// </summary>
        [HttpGet("GetAllProducts")]
        [Produces("application/json")]
        public async Task<List<ProductEntity>> GetAllProducts()   // Read all Products data in Cache -> L1/L2/L3
        {
            ProductServiceHybrid _productRepository = new ProductServiceHybrid(_appDbContext, _cache);
            List <ProductEntity> productList = new List<ProductEntity>();
            productList = await _productRepository.GetAllProducts(_cache, _appDbContext, CancellationToken.None);
            return productList;
        }

        /// <summary>
        ///  Read One Product Id from Cache -> L1/L2/L3/L4
        /// </summary>
        [HttpGet("GetProductById")]
        [Produces("application/json")]
        public async Task<ProductEntity> GetProductById(string _cacheKey)   // Read one item in cache by Id -> L1/L2/L3
        {
            ProductServiceHybrid _productRepository = new ProductServiceHybrid(_appDbContext, _cache);
            ProductEntity product = new ProductEntity();
            product = await _productRepository.GetProductById(_cacheKey, _cache, _appDbContext, CancellationToken.None);
            return product;
        }

        /// <summary>
        /// Add One New ProductEntity to Cache
        /// </summary>
        [HttpPost("AddProductToCache")]
        [Produces("application/json")]
        public async Task<bool> AddProductToCache(ProductEntity productEntity)   // Add one new Product Entity to Cache
        {
            ProductServiceHybrid _productRepository = new ProductServiceHybrid(_appDbContext, _cache);
            bool productStatus = await _productRepository.AddProductToCache(productEntity.Id.ToString(), productEntity, _cache, CancellationToken.None);

            return true;
        }

        /// <summary>
        ///  Remove an Item  from Cache
        /// </summary>
        [HttpGet("RemoveItemFromCache")]
        [Produces("application/json")]
        public async Task<bool> RemoveItemFromCache(ProductEntity productEntity)   // Remove Entity from Cache
        {
            ProductServiceHybrid _productRepository = new ProductServiceHybrid(_appDbContext, _cache);
            bool productStatus = await _productRepository.RemoveItemFromCache(productEntity.Id.ToString(), _cache, CancellationToken.None);

            return true;
        }

        /// <summary>
        ///  Get Execution Stats on this Cache
        /// </summary>
        [HttpGet("GetStats")]
        [Produces("application/json")]
        public string GetStats()   // GetStats Hit & Miss
        {
            ProductServiceHybrid _productRepository = new ProductServiceHybrid(_appDbContext, _cache);
            string  stats = _productRepository.GetStats();
            return stats;
        }
    }
}
