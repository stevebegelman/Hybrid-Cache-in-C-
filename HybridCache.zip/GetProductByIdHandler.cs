﻿using CacheAggregator.Application.Contracts.Persistence;
using CacheAggregator.Domain.Entities;
using MediatR;
using Microsoft.Extensions.Caching.Hybrid;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CacheAggregator.Application.Features.Products.Queries
{
    public class GetProductByIdHandler : IRequestHandler<GetProductByIdQuery, ProductEntity>
    {
        private readonly HybridCache _cache;
        private readonly AppDbContext _context;

        public readonly bool? optimisticBehaviour = StatUtility.optimisticBehaviour; // Cache Only! : No Database Action -> "Cache or Nothing" is Default
        public HybridCacheEntryOptions? cacheOptions;

        private object locker = 1;
        public GetProductByIdHandler(HybridCache cache, AppDbContext context)
        {
            _cache = cache;
            _context = context;
        }
        public async Task<ProductEntity> Handle(GetProductByIdQuery request, CancellationToken cancellationToken)
        {
            StatUtility.executions++;
            var cacheKey = $"product-" + request.id;

            // Use HybridCache to fetch data from either L1 or L2
            #pragma warning disable CS8603 // Possible null reference return.
                var cacheResult = await _cache.GetOrCreateAsync(
                    cacheKey,
                    async token => await FetchProductFromDatabase(cacheKey, token),
                    new HybridCacheEntryOptions
                    {
                        Expiration = TimeSpan.FromMinutes(30), // Shared expiration for L1 and L2
                        LocalCacheExpiration = TimeSpan.FromMinutes(10) // L1 expiration
                    }, null, CancellationToken.None
                );
                return cacheResult;
            #pragma warning restore CS8603 // Possible null reference return.
        }
        private Task<ProductEntity?> FetchProductFromDatabase(string cacheKey, CancellationToken cancellationToken)
        {
            ProductEntity? product = null;

            if (optimisticBehaviour == false)
            {
                var tmp = cacheKey.Replace("product-", null);
                var realGuid = new Guid(tmp);

                product = _context.Products.FirstOrDefault(p => p.Id == realGuid);

                Debug.WriteLine("Miss!");
                StatUtility.misses++;
            }

            if (optimisticBehaviour == true)
            {
                StatUtility.misses++;
                return Task.FromResult(product);
            }
            return Task.FromResult(product);
        }
    }
}
