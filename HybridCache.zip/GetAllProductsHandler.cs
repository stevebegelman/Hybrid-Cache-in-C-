﻿using CacheAggregator.Application.Contracts.Persistence;
using CacheAggregator.Domain.Entities;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Hybrid;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CacheAggregator.Application.Features.Products.Queries
{
    public class GetAllProductsHandler : IRequestHandler<GetAllProductsQuery, List<ProductEntity>>
    {
        private readonly HybridCache _cache;
        private readonly AppDbContext _context;

        public readonly bool? optimisticBehaviour = StatUtility.optimisticBehaviour; // Cache Only! : No Database Action -> "Cache or Nothing" is Default
        public HybridCacheEntryOptions? cacheOptions;

        private object locker = 1;
        public GetAllProductsHandler(HybridCache cache, AppDbContext context)
        {
            _cache = cache;
            _context = context;
        }
        public async Task<List<ProductEntity>> Handle(GetAllProductsQuery request, CancellationToken cancellationToken)
        {
            StatUtility.executions++;
            var cacheKey = "products";

            // Use HybridCache to fetch data from either L1 or L2
            return await _cache.GetOrCreateAsync(
                cacheKey,
                async token => await FetchProductsFromDatabaseAsync(cacheKey, token),
                new HybridCacheEntryOptions
                {
                    Expiration = TimeSpan.FromMinutes(30), // Shared expiration for L1 and L2
                    LocalCacheExpiration = TimeSpan.FromMinutes(10) // L1 expiration
                }, null,
                CancellationToken.None
            );
        }

        public async Task<List<ProductEntity>> FetchProductsFromDatabaseAsync(string cacheKey, CancellationToken cancellationToken)
        {
            List<ProductEntity> products = new List<ProductEntity>();

            if (optimisticBehaviour == false)
            {
                products = await _context.Products.ToListAsync();
                Debug.WriteLine("Miss!");
                StatUtility.misses++;
                return products;
            }

            if (optimisticBehaviour == true)
            {
                StatUtility.misses++;
                return products;
            }
            return products;
        }
    }
}
