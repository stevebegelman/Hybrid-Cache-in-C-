﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.ComponentModel.DataAnnotations;
using CacheAggregator.Domain.Common;

 namespace CacheAggregator.Application.Features
{
    public class ProductEntityDto
    {
        public  Guid Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public Guid SupplierId { get; set; } 
    }
}
