﻿using Candriam.Persistency.Dapper.SQL.Providers;
using Dapper;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.Common;

namespace CacheAggregator.Application.UnitTests
{

    /// <summary>
    /// This set of tools have been created to find a work around on READ_ONLY
    /// </summary>
    public class Tools
    {
        private static bool sEngineReconfigured = false;
        public static void ReconfigureDBEngine()
        {
            //////
            /// in the appsettings.json
            /// 
            /// "DefaultConnectionAttach": "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename={AppContextPath}TestDB\\SilverAPIRealmDB_Primary.mdf;Integrated Security=True;Connect Timeout=30",
            /// "DefaultConnection": "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog={CatalogDbName};Persist Security Info=False;User ID=DbUser;Password=StrongPassword123!;Pooling=False;Multiple Active Result Sets=False;Encrypt=False;Trust Server Certificate=True;Command Timeout=0",
            /// "MasterConnection": "Data Source=(LocalDB)\\MSSQLLocalDB;Database=Master;Integrated Security=True;Connect Timeout=30",
            /// 

            /// Use CustomSqlServerDatabaseProvider instead of default one
            //////

            if (!sEngineReconfigured)
            {
                SqlServerDatabaseProvider sqlServerDatabaseProvider = new SqlServerDatabaseProvider() { ConnectionName = "MasterConnection" };
                using (DbConnection dbConnection = sqlServerDatabaseProvider.GetOpenConnection())
                {

                    using (DbCommand command = dbConnection.CreateCommand())
                    {
                        command.CommandType = CommandType.Text;
                        command.CommandTimeout = 30;
                        command.CommandText = "sp_configure 'CONTAINED DATABASE AUTHENTICATION', 0; RECONFIGURE WITH OVERRIDE;";

                        command.ExecuteNonQuery();
                        Console.WriteLine("RECONFIGURE command executed successfully.");
                    }

                    // dbConnection.ExecuteScalar($"sp_configure 'CONTAINED DATABASE AUTHENTICATION', 1");
                    //dbConnection.ExecuteScalar($"RECONFIGURE");
                    dbConnection.Close();
                }
                sEngineReconfigured = true;
            }
        }

        public static void EnsureDBIsRW_old()
        {
            SqlServerDatabaseProvider sqlServerDatabaseProvider = new SqlServerDatabaseProvider();
            DbConnection dbConnection = sqlServerDatabaseProvider.GetOpenConnection();
            //string command = $"ALTER DATABASE \"{ExtractDbName()}\" SET READ_WRITE WITH NO_WAIT;";

            string command = $"ALTER DATABASE \"{ExtractDbName()}\" SET READ_WRITE WITH NO_WAIT;";
            dbConnection.ExecuteScalar(command);
            dbConnection.Close();
        }

        public static void EnsureDBIsRW()
        {

            // First initiate named pipes

            //SqlServerDatabaseProvider sqlServerDatabaseProvider = new CustomSqlServerDatabaseProvider() { ConnectionName = "DefaultConnectionIntegrated" };
            //using (DbConnection dbConnection = sqlServerDatabaseProvider.GetOpenConnection())
            //{
            //    dbConnection.Close();
            //}

            string name;

            SqlServerDatabaseProvider sqlServerDatabaseProvider2 = new SqlServerDatabaseProvider() /*{ ConnectionName = "MasterConnection" }*/;
            using (DbConnection dbConnection = sqlServerDatabaseProvider2.GetOpenConnection())
            {
                name = dbConnection.ExecuteScalar<String>("SELECT DB_NAME() AS DatabaseName;");

                //dbConnection.ExecuteScalar<String>($"ALTER DATABASE \"{name}\" SET OFFLINE;");

                string Sqlcommand = $"ALTER DATABASE \"{name}\" SET READ_WRITE WITH NO_WAIT";
                using (DbCommand command = dbConnection.CreateCommand())
                {
                    command.CommandType = CommandType.Text;
                    command.CommandTimeout = 30; // This is not working 
                    command.CommandText = Sqlcommand;

                    command.ExecuteNonQuery();
                }
                dbConnection.Close();
            }

            //sqlServerDatabaseProvider = new CustomSqlServerDatabaseProvider() { ConnectionName = "MasterConnection" };
            //using (DbConnection dbConnection = sqlServerDatabaseProvider.GetOpenConnection())
            //{
            //    string Sqlcommand = $"ALTER DATABASE \"{name}\" SET READ_ONLY";
            //    using (DbCommand command = dbConnection.CreateCommand())
            //    {
            //        command.CommandType = CommandType.Text;
            //        command.CommandTimeout = 30; // This is not working 
            //        command.CommandText = Sqlcommand;

            //        command.ExecuteNonQuery();

            //        dbConnection.Close();
            //    }
            //}

            // dbConnection.ExecuteScalar<String>($"ALTER DATABASE \"{name}\" SET ONLINE;");

            //sqlServerDatabaseProvider = new CustomSqlServerDatabaseProvider() { ConnectionName = "MasterConnection" };
            //using (DbConnection dbConnection = sqlServerDatabaseProvider.GetOpenConnection())
            //{
            //    dbConnection.ExecuteScalar<String>($"ALTER DATABASE \"{name}\" SET SINGLE_USER WITH ROLLBACK IMMEDIATE;");
            //    dbConnection.ExecuteScalar<String>($"master.dbo.sp_detach_db @dbname = N\'{name}'");
            //    dbConnection.Close();
            //}
        }

        private static String _sAttachedDbName = String.Empty;
        public static string ExtractDbName()
        {
            if (String.IsNullOrEmpty(_sAttachedDbName))
            {
                SqlServerDatabaseProvider sqlServerDatabaseProvider = new SqlServerDatabaseProvider() { ConnectionName = "DefaultConnection" };
                DbConnection dbConnection = sqlServerDatabaseProvider.GetOpenConnection();
                _sAttachedDbName = dbConnection.ExecuteScalar<String>("SELECT DB_NAME() AS DatabaseName;");
                dbConnection.Close();
            }

            return _sAttachedDbName;
        }

        private static String _sAttachedCx = String.Empty;
        public static string MakeAttachedConnectionString()
        {
            if (String.IsNullOrEmpty(_sAttachedCx))
            {
                _sAttachedCx = GetConnectionString("DefaultConnectionByCatalog");
                _sAttachedCx = _sAttachedCx.Replace("{CatalogDbName}", ExtractDbName());
            }
            return _sAttachedCx;
        }

        public static string GetConnectionString(string connectionName)
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                .AddJsonFile("appsettings.json")
                .Build();

            return configuration.GetConnectionString(connectionName);
        }


    }
}
