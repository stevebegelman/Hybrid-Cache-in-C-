﻿using Microsoft.AspNetCore.Mvc.Testing;
using RestAssured.Response;
using System.Net;
using CacheAggregator.Api;
using static RestAssured.Dsl;

namespace CacheAggregator.Application.UnitTests.Continents
{
    public class ApiBase
    {
        private TestWebApplicationFactory<Program> _twaf;
        public HttpClient Client { get; private set; }

        private String? _bearerToken;

        public PersistenceTarget Context { get; private set; }

        internal void Init(PersistenceTarget persistenceTarget)
        {
            Context = persistenceTarget;
            // Tools.EnsureDBIsRW();

            _twaf = new TestWebApplicationFactory<Program>(persistenceTarget);

            WebApplicationFactoryClientOptions clientOptions = new WebApplicationFactoryClientOptions();
            clientOptions.BaseAddress = new Uri("https://localhost");
            Client = _twaf.CreateClient(clientOptions);

        }

        internal string RetrieveBearerToken()
        {
            if (_bearerToken == null)
            {
                // Create a confidential client application
                var confidentialClientApp = ConfidentialClientApplicationBuilder
                    .Create("da92030f-2ff5-47fd-abd9-0cc837f52bd9")
                    .WithClientSecret("rnI8Q~bNK.t3wELL5lhPYpGY2jHAK0nMSjUURc0b")
                    .WithAuthority(new Uri("https://login.microsoftonline.com/fd66b2a1-7a4f-4875-a3df-f2adb0a621a5/oauth2/v2.0/token"))
                    .Build();

                // Define the scopes you need
                string[] scopes = new[] { "api://167d9b2a-d726-438a-b567-737b6bff70ee/.default" }; // Replace with your desired scopes

                // Acquire an access token
                var authResult = confidentialClientApp.AcquireTokenForClient(scopes).ExecuteAsync();
                _bearerToken = authResult.Result.AccessToken;
            }

            return _bearerToken;
        }

        internal ExtractableResponse? LaunchGetRequest(string url, HttpStatusCode expectedStatus = HttpStatusCode.OK, string expectedResponseBody = null)
        {
            ExtractableResponse? response = default!;

            if (expectedResponseBody == null)
            {
                response = Given(Client)
                .When()
                .Header("Accept", "*/*")
                .Header("Accept-Encoding", "gzip, deflate, br")
                .Header("Authorization", "Bearer " + RetrieveBearerToken())
                .Header("Connection", "keep-alive")
                .Get(url)
                .Then()
                .StatusCode(expectedStatus)
                .Extract();
            }
            else
            {
                response = Given(Client)
                .When()
                .Header("Accept", "*/*")
                .Header("Accept-Encoding", "gzip, deflate, br")
                .Header("Authorization", "Bearer " + RetrieveBearerToken())
                .Get(url)
                .Then()
                .StatusCode(HttpStatusCode.OK)
                .Body(expectedResponseBody)
                .Extract();

            }

            return response;
        }

        internal ExtractableResponse? LaunchPostRequest(string url, string body, HttpStatusCode expectedStatus = HttpStatusCode.OK, string expectedResponseBody = null)
        {
            ExtractableResponse? response = default!;

            if (expectedResponseBody == null)
            {
                response = Given(Client)
                .When()
                .Header("Accept", "*/*")
                .Header("Accept-Encoding", "gzip, deflate, br")
                .Header("Authorization", "Bearer " + RetrieveBearerToken())
                .Body(body)
                .Post(url)
                .Then()
                .StatusCode(expectedStatus)
                .Extract();
            }
            else
            {
                response = Given(Client)
               .When()
               .Header("Accept", "*/*")
               .Header("Accept-Encoding", "gzip, deflate, br")
               .Header("Authorization", "Bearer " + RetrieveBearerToken())
               .Body(body)
               .Post(url)
               .Then()
               .StatusCode(HttpStatusCode.OK)
               .Body(expectedResponseBody)
               .Extract();
            }

            return response;
        }

        internal ExtractableResponse? LaunchPutRequest(string url, string body, HttpStatusCode expectedStatus = HttpStatusCode.OK, string expectedResponseBody = null)
        {
            ExtractableResponse? response = default!;

            if (expectedResponseBody == null)
            {
                response = Given(Client)
                .When()
                .Header("Accept", "*/*")
                .Header("Accept-Encoding", "gzip, deflate, br")
                .Header("Authorization", "Bearer " + RetrieveBearerToken())
                .Body(body)
                .Put(url)
                .Then()
                .StatusCode(expectedStatus)
                .Extract();
            }
            else
            {
                response = Given(Client)
               .When()
               .Header("Accept", "*/*")
               .Header("Accept-Encoding", "gzip, deflate, br")
               .Header("Authorization", "Bearer " + RetrieveBearerToken())
               .Body(body)
               .Put(url)
               .Then()
               .StatusCode(HttpStatusCode.OK)
               .Body(expectedResponseBody)
               .Extract();
            }

            return response;
        }

        internal ExtractableResponse? LaunchDeleteRequest(string url, HttpStatusCode expectedStatus = HttpStatusCode.OK, string expectedResponseBody = null)
        {
            ExtractableResponse? response = default!;

            if (expectedResponseBody == null)
            {
                response = Given(Client)
                .When()
                .Header("Accept", "*/*")
                .Header("Accept-Encoding", "gzip, deflate, br")
                .Header("Authorization", "Bearer " + RetrieveBearerToken())
                .Delete(url)
                .Then()
                .StatusCode(expectedStatus)
                .Extract();
            }
            else
            {
                response = Given(Client)
                .When()
                .Header("Accept", "*/*")
                .Header("Accept-Encoding", "gzip, deflate, br")
                .Header("Authorization", "Bearer " + RetrieveBearerToken())
                .Delete(url)
                .Then()
                .StatusCode(HttpStatusCode.OK)
                .Body(expectedResponseBody)
                .Extract();

            }
            return response;
        }

        internal ExtractableResponse? LaunchHealthCheckRequest(string url, string secretToken = "", HttpStatusCode expectedStatus = HttpStatusCode.OK, string expectedResponseBody = null)
        {
            ExtractableResponse? response = default!;

            if (expectedResponseBody == null)
            {
                response = Given(Client)
                .When()
                .Header("Accept", "*/*")
                .Header("Accept-Encoding", "gzip, deflate, br")
                .Header("X-Api-Health-Check-Token", secretToken)
                .Head(url)
                .Then()
                .StatusCode(expectedStatus)
                .Extract();
            }
            else
            {
                response = Given(Client)
                .When()
                .Header("Accept", "*/*")
                .Header("Accept-Encoding", "gzip, deflate, br")
                .Header("X-Api-Health-Check-Token", secretToken)
                .Head(url)
                .Then()
                .StatusCode(HttpStatusCode.OK)
                .Body(expectedResponseBody)
                .Extract();

            }

            return response;
        }

    }
}


