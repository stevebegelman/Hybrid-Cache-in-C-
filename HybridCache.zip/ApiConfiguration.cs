﻿namespace UnitTests.Configuration
{
    public class ApiConfiguration
    {

        public string AppServiceNameApi { get; set; } = string.Empty;
        public string RedirectUri { get; set; } = string.Empty;
        public string Scope { get; set; } = string.Empty;
    }
}
