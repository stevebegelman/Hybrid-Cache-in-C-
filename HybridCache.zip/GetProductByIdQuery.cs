﻿using CacheAggregator.Application.Contracts.Persistence;
using CacheAggregator.Domain.Entities;
using MediatR;
using Microsoft.Extensions.Caching.Hybrid;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CacheAggregator.Application.Features.Products.Queries
{
    public class GetProductByIdQuery : IRequest<ProductEntity>
    {
        public string id { get; set; } = string.Empty;
        public CancellationToken token { get; set; } = default;
    }
}
