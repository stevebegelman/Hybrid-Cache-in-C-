﻿using CacheAggregator.Application.Contracts.Persistence;
using CacheAggregator.Domain.Entities;
using MediatR;
using Microsoft.Extensions.Caching.Hybrid;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CacheAggregator.Application.Features.Products.Queries
{
    public class CreateInitialCacheDataHandler : IRequestHandler<CreateInitialCacheDataQuery, List<ProductEntity>>
    {
        public async Task<List<ProductEntity>> Handle(CreateInitialCacheDataQuery request, CancellationToken cancellationToken)
        {
            List<ProductEntity> listProducts = new List<ProductEntity>();
            ProductEntity productEntity = new ProductEntity();

            for (int i = 0; i < request.nbrLines; i++)
            {
                productEntity.Id = Guid.NewGuid();
                productEntity.Name = "product-" + i.ToString();
                productEntity.Price = (i * 2) + 50;
                productEntity.Description = "Product Description";

                Guid x = new Guid("00000002-0000-0000-0000-000000000000");

                productEntity.SupplierId = x;

                // from Base
                productEntity.CreatedBy = "Tatiana Golova";
                productEntity.CreatedDate = DateTime.Now.AddDays(-4);
                productEntity.LastModifiedBy = "Diana Gontcharova";
                productEntity.LastModifiedDate = DateTime.Now;

                listProducts.Add(productEntity);
                productEntity = new ProductEntity();
            }
            if (request.nbrLines == listProducts.Count) StatUtility.executions++;
                else StatUtility.misses++;  

            return await Task.FromResult(listProducts);
        }
    }
}
