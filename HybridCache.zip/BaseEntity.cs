﻿namespace CacheAggregator.Domain.Common
{
    public class BaseEntity
    {
        public string? CreatedBy { get; set; } = "sb";
        public DateTimeOffset CreatedDate { get; set; } = DateTimeOffset.Now;
        public string? LastModifiedBy { get; set; } = "sb";
        public DateTimeOffset? LastModifiedDate { get; set; } = DateTimeOffset.Now; 
        public String Id { get; set; } = String.Empty;
    }
}