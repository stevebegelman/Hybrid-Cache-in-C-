﻿using Candriam.Api.Versioning;
using Candriam.Application.Behaviours;
using Candriam.Messaging.MQ;
using Candriam.Shared.Contract.Configuration;

using Serilog;
using Serilog.Events;

using CacheAggregator.Application;

/*
using CacheAggregator.Persistence.Dapper.SqlServer;
using CacheAggregator.Persistence.EF.SqlServer;
*/

using CacheAggregator.Persistence.TableStorage;
using Microsoft.EntityFrameworkCore;
using System;
using CacheAggregator.Application.Contracts.Persistence;
using CacheAggregator.Application.Features;
using Microsoft.Extensions.Caching.Hybrid;
using Microsoft.AspNetCore.Mvc;


namespace CacheAggregator.Api
{
    /// <summary>
    /// StartupExtensions
    /// </summary>
    public static class StartupExtensions
    {

        /// <summary>
        /// Startup Extension
        /// </summary>
        /// <param name="builder">The <see cref="WebApplicationBuilder"/> instance.</param>
        /// <param name="persistenceTarget">The <see cref="PersistenceTarget"/> enumaration to switch from one persistence to another.</param>
        /// <returns></returns>
        public static WebApplication ConfigureServices(this WebApplicationBuilder builder, PersistenceTarget persistenceTarget = PersistenceTarget.SqlServerViaEntityFramework)
        {
            builder.Services.AddSwaggerGen(c => c.EnableAnnotations());

            // Distrib  Cache Specific
            builder.Services.AddAuthorization();
            #pragma warning disable EXTEXP0018 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.
            builder.Services.AddHybridCache(options =>
            {
                options.MaximumPayloadBytes = 1024 * 1024 * 10; // 10 MB
                options.MaximumKeyLength = 512;
                options.DefaultEntryOptions = new HybridCacheEntryOptions
                {
                    Expiration = TimeSpan.FromMinutes(60 * 12),            // 12 hours = 1 Working day  7H -> 19H
                    LocalCacheExpiration = TimeSpan.FromMinutes(60 * 12)   // 12 hours = 1 Working day  7H -> 19H
                };
            });
            #pragma warning restore EXTEXP0018 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.
            // Distrib  Cache Specific

            // Connection String for Dapper
            var connectionString = builder.Configuration.GetConnectionString("LocalConnection");

            // If Entity (later)
            builder.Services.AddDbContext<AppDbContext>(options => options.UseSqlServer(connectionString));

            builder.Services.AddDistributedMemoryCache((options => options.TrackStatistics = true));

            //builder.Services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);  DEPRECATED

            /*   Uncomment to Activate Persistant Backing Store
            builder.Services.AddDistributedSqlServerCache(options =>
            {
                options.ConnectionString = builder.Configuration.GetConnectionString(
                    "CacheAdmin");
                options.SchemaName = "dbo";
                options.TableName = "DistCache";
            });
            */

            builder.Services.AddTransient<IProductRepository, ProductServiceHybrid>();

            //External Contract [Candriam.Shared.Contract] :: Bind Secret Settings
            builder.Services.Configure<Secrets>(builder.Configuration.GetSection("Secrets"));

            //Register Core.Application
            builder.Services.AddApplicationServices();

            //Register Infrastructure.Persistency
            switch (persistenceTarget)
            {
                case PersistenceTarget.AzureTableStorage:
                    builder.Services.AddPersistenceServices(builder.Configuration);
                    break;
                //case PersistenceTarget.SqlServerViaEntityFramework:
                //    builder.Services.AddEFSqlPersistenceServices(builder.Configuration);
                //    break;
                //case PersistenceTarget.SqlServerViaDapper:
                //    builder.Services.SqlDapperPersistenceServiceRegistration(builder.Configuration);
                //    break;
            }

            //Register MQ Series Services
            builder.Services.AddInfrastructureMessagingServices(builder.Configuration);

            //External Package [Candriam.Api.Versioning] :: Register API versioning + swagger definition
            builder.Services.AddApiVersioningServices();

            //External Package [Candriam.Application.Behaviours] :: Register Validator
            builder.Services.AddValidationBehaviours();

            //External Package [Candriam.Application.Behaviours] :: Register Exception Middleware
            builder.Services.AddExceptionHandler();

            builder.Services.AddHttpContextAccessor();
            builder.Services.AddControllers();
            builder.Services.AddCors(opt =>
            {
                opt.AddPolicy("Open", config => config.AllowAnyOrigin()
                    .AllowAnyHeader()
                    .AllowAnyMethod());
            });


            return builder.Build();
        }

        /// <summary>
        /// ConfigurePipeline
        /// </summary>
        /// <param name="app"></param>
        /// <returns></returns>
        public static WebApplication ConfigurePipeline(this WebApplication app)
        {
            //External Package [Candriam.Api.Versioning]
            app.UseApiVersioning();

            app.UseSerilogRequestLogging(options =>
            {

                options.GetLevel = (httpContext, elapsed, ex) =>
                {
                    switch (httpContext.Response.StatusCode)
                    {
                        case 400:
                            return LogEventLevel.Warning;
                        case 404:
                            return LogEventLevel.Warning;
                        case > 499:
                            return LogEventLevel.Error;
                    }

                    return LogEventLevel.Information;
                };
            });

            app.UseExceptionHandler();

            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseCors("Open");

            app.UseAuthentication();
            app.UseAuthorization();


            app.MapControllers();

            // for  OData
            app.UseDefaultFiles();
            app.UseStaticFiles();
            app.UseHttpsRedirection();
            // for  OData


            return app;
        }
    }
}
