﻿using CacheAggregator.Application.Contracts.Persistence;
using CacheAggregator.Domain.Entities;
using MediatR;
using Microsoft.Extensions.Caching.Hybrid;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CacheAggregator.Application.Features.Products.Queries
{
    public class PushInitialProductDataToCacheHandler : IRequestHandler<PushInitialProductDataToCacheQuery, bool>
    {
        private readonly HybridCache _cache; 
        private readonly AppDbContext _context;

        public PushInitialProductDataToCacheHandler(HybridCache cache, AppDbContext context)
        {
            _cache = cache;
            _context = context;
        }
        public async Task<bool> Handle(PushInitialProductDataToCacheQuery request, CancellationToken cancellationToken)
        {
            StatUtility.executions++;
            var cStatus = _cache.GetType();
            string cacheKey = "products";

            try
            {
                await _cache.SetAsync(
                    cacheKey,
                    request.productData,
                    new HybridCacheEntryOptions
                    {
                        Expiration = TimeSpan.FromMinutes(60), // Set expiration
                        LocalCacheExpiration = TimeSpan.FromMinutes(60), // L1 expiration
                    }, null,
                    cancellationToken
                );
            }
            catch (Exception)
            {
                StatUtility.misses++;
                return false;
            }
            return true;
        }
    }
}
