﻿using Candriam.Persistency.StorageAccount;
using Candriam.Shared.Contract.Configuration;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;
using CacheAggregator.Application.Contracts.Persistence;


namespace CacheAggregator.Persistence.TableStorage
{
    public static class PersistenceServiceRegistration
    {
        public static IServiceCollection AddPersistenceServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddAutoMapper(Assembly.GetExecutingAssembly());
;

            services.AddSingleton<TableStorageContext>();

            services.Configure<ConnectionStringConfiguration>(configuration.GetSection("ConnectionStrings"));


            //services.AddScoped<IAsyncRepository<ProductEntity, string>, ProductServiceHybrid>();


            services.AddScoped<IProductRepository, ProductServiceHybrid>();

            return services;
        }
    }
}