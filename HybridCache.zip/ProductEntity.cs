﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.ComponentModel.DataAnnotations;
using CacheAggregator.Domain.Common;

namespace CacheAggregator.Domain.Entities
{
    [Serializable()]
    public class ProductEntity : BaseEntityCache
    {
        [Key]
        public  Guid Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public Guid SupplierId { get; set; }

        public ProductEntity() { } 

        public ProductEntity(string name, string description, decimal price, Guid supplierid)
        {
            Name = name;
            Description = description;
            Price = price;
            SupplierId = supplierid;
        }
        // Optional Serializer for Shared Memory:
        // -------------------------------------
        public byte[] SerializeProduct()
        {
            using (MemoryStream m = new MemoryStream())
            {
                using (BinaryWriter writer = new BinaryWriter(m))
                {
                    writer.Write(Id.ToByteArray());
                    writer.Write(Name);
                    writer.Write(Description);
                    writer.Write(Price);
                    writer.Write(SupplierId.ToByteArray());
                }
                return m.ToArray();
            }
        }

        public ProductEntity DeserializeProduct(byte[] data)
        {
            ProductEntity result = new ProductEntity();

            using (MemoryStream m = new MemoryStream(data))
            {
                using (BinaryReader reader = new BinaryReader(m))
                {
                    byte[] guidBytes = reader.ReadBytes(16); // Guid is 16 bytes
                    result.Id = new Guid(guidBytes);

                    result.Name = reader.ReadString();
                    result.Description = reader.ReadString();
                    result.Price = reader.ReadDecimal();

                    byte[]? guidBytes2 = reader.ReadBytes(16); // Guid is 16 bytes
                    result.SupplierId = new Guid(guidBytes2);
                }
            }
            return result;
        }
    }
}
