﻿//using AutoMapper;
//using CacheAggregator.Domain.Entities;
//using CacheAggregator.Persistence.TableStorage.TableEntity;

//namespace CacheAggregator.Persistence.TableStorage.Profiles
//{
//    public class MappingProfile : Profile
//    {
//        public MappingProfile()
//        {
//            CreateMap<ContinentEntity, ContinentTableEntity>()
//                .ForMember(dest => dest.RowKey,
//                    opt => opt.MapFrom(src => src.Id.ToString())) // ==> RowKey is mapped to Alias
//                .ForMember(dest => dest.PartitionKey, opt => opt.MapFrom(src => "CONTINENT"));
//            //.ForMember(dest => dest.ContinentId, opt => opt.MapFrom(src => src.ContinentId))
//            //.ForMember(dest => dest.ContinentName, opt => opt.MapFrom(src => src.ContinentName));
//            //.ReverseMap();
//            CreateMap<ContinentTableEntity, ContinentEntity>()
//                .ForMember(dest => dest.Id,
//                    opt => opt.MapFrom(src => Guid.Parse(src.RowKey.ToString()))); // ==> RowKey is mapped to Alias
//                                                                                   //.ForMember(dest => dest.ContinentId, opt => opt.MapFrom(src => src.ContinentId))
//                                                                                   //.ForMember(dest => dest.ContinentName, opt => opt.MapFrom(src => src.ContinentName));

//            CreateMap<CountryEntity, CountryTableEntity>()
//               .ForMember(dest => dest.RowKey,
//                   opt => opt.MapFrom(src => src.Id.ToString())) // ==> RowKey is mapped to Alias
//               .ForMember(dest => dest.PartitionKey, opt => opt.MapFrom(src => "COUNTRY"));


//            CreateMap<CountryTableEntity, CountryEntity>()
//                .ForMember(dest => dest.Id,
//                    opt => opt.MapFrom(src => Guid.Parse(src.RowKey.ToString()))); // ==> RowKey is mapped to Alias


//            CreateMap<CityEntity, CityTableEntity>()
//               .ForMember(dest => dest.RowKey,
//                   opt => opt.MapFrom(src => src.Id.ToString())) // ==> RowKey is mapped to Alias
//               .ForMember(dest => dest.PartitionKey, opt => opt.MapFrom(src => "CITY"));

//            CreateMap<CityTableEntity, CityEntity>()
//                .ForMember(dest => dest.Id,
//                    opt => opt.MapFrom(src => Guid.Parse(src.RowKey.ToString())));
//        }
//    }
//}