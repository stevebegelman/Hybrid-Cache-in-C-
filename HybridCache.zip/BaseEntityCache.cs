﻿
// The Unique Monotonic Key is NOT an inherirted attribute, put a GUID which is GUID()
// Note that in the next generation the DateTime attributed must be modified into DateTimeOffset

namespace CacheAggregator.Domain.Common
{
    public class BaseEntityCache
    {
        public string? CreatedBy { get; set; } = "sb";
        public DateTime? CreatedDate { get; set; } = DateTime.Now;
        public string? LastModifiedBy { get; set; } = "sb";
        public DateTime? LastModifiedDate { get; set; } = DateTime.Now;
    }
}