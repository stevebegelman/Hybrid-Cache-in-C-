﻿using Azure;
using Candriam.Persistency.StorageAccount;
using System.Runtime.Serialization;
using CacheAggregator.Domain.Entities;

namespace CacheAggregator.Persistence.TableStorage.TableEntity
{
    public class ProductTableEntity : ProductEntity, ITableEntityExtend
    {
        [IgnoreDataMember]
        public string TableName => "Products";
        public string PartitionKey { get; set; } = string.Empty;
        public string RowKey { get; set; } = string.Empty;
        public DateTimeOffset? Timestamp { get; set; } = DateTimeOffset.Now;
        public ETag ETag { get; set; }
    }
}
