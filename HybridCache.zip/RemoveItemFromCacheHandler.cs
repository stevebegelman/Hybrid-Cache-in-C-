﻿using CacheAggregator.Application.Contracts.Persistence;
using CacheAggregator.Domain.Entities;
using MediatR;
using Microsoft.Extensions.Caching.Hybrid;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CacheAggregator.Application.Features.Products.Queries
{
    public class RemoveItemFromCacheHandler : IRequestHandler<RemoveItemFromCacheQuery, bool>
    {
        private readonly HybridCache _cache;
        private readonly AppDbContext _context;

        public RemoveItemFromCacheHandler(HybridCache cache, AppDbContext context)
        {
            _cache = cache;
            _context = context;
        }

        public async Task<bool> Handle(RemoveItemFromCacheQuery request, CancellationToken cancellationToken)
        {
            StatUtility.executions++;
            var cacheKey = request.name + "-" + request.id;    
            try
            {
                await _cache.RemoveAsync(
                                    cacheKey,
                                    cancellationToken

                );
            }
            catch (Exception)
            {
                StatUtility.misses++;
                return false;
            }
            return true;
        }
    }
}
