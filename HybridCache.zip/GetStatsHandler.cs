﻿using CacheAggregator.Application.Contracts.Persistence;
using CacheAggregator.Domain.Entities;
using MediatR;
using Microsoft.Extensions.Caching.Hybrid;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CacheAggregator.Application.Features.Products.Queries
{
    public class GetStatsHandler : IRequestHandler<GetStatsQuery, string>
    {
        private readonly HybridCache _cache;
        private readonly AppDbContext _context;

        public GetStatsHandler(HybridCache cache, AppDbContext context)
        {
            _cache = cache;
            _context = context;
        }

        public Task<string> Handle(GetStatsQuery request, CancellationToken cancellationToken)
        {
            if (StatUtility.executions >= 1)
            {
                double Executions = StatUtility.executions;
                double Misses = StatUtility.misses;
                string Ratio = "";

                Ratio = Math.Round(((Executions - Misses) / Executions) * 100, 2).ToString();

                string stats = string.Format("Total Transactions = {0} Total Hits = {1}  Total Misses = {2} Hit Rate % = {3} ",
                                             StatUtility.executions, StatUtility.executions - StatUtility.misses, StatUtility.misses, Ratio);
                return Task.FromResult(stats);
            }
            return Task.FromResult("No Valid Stats");
        }
    }
}


