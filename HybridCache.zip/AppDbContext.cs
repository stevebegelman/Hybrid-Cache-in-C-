﻿using CacheAggregator.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace CacheAggregator.Application.Contracts.Persistence
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
            Database.EnsureCreated();
        }
        public DbSet<ProductEntity> Products { get; set; }

        //public DbSet<Supplier> Suppliers { get; set; }
        //public DbSet<ProductSupplier> ProductSupplier { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ProductEntity>().HasKey(p => p.Id);

            //modelBuilder.Entity<Product>().HasOne<Supplier>();
            //modelBuilder.Entity<Supplier>().HasKey(p => p.Id);

            //modelBuilder.Entity<ProductSupplier>()
            //            .ToView(nameof(ProductSupplier))
            //            .HasKey(p => p.Id);

        }
    }
}


