using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net;
using System.ComponentModel.DataAnnotations;
using System.Net.Http.Formatting;


using System.Diagnostics;
using System.Text.Json;

namespace HttpClientDemo
{
    public class ProductEntity 
    {
        [Key]
        public Guid Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public Guid SupplierId { get; set; }

        //
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string LastModifiedBy { get; set; } = "LLM";
        public DateTime LastModifiedDate { get; set; } = DateTime.Now;
        public ProductEntity() { }

        public ProductEntity(string name, string description, decimal price, Guid supplierid)
        {
            Name = name;
            Description = description;
            Price = price;
            SupplierId = supplierid;
        }
        // Optional Serializer for Shared Memory:
        // -------------------------------------
        public byte[] SerializeProduct()
        {
            using (MemoryStream m = new MemoryStream())
            {
                using (BinaryWriter writer = new BinaryWriter(m))
                {
                    writer.Write(Id.ToByteArray());
                    writer.Write(Name);
                    writer.Write(Description);
                    writer.Write(Price);
                    writer.Write(SupplierId.ToByteArray());
                }
                return m.ToArray();
            }
        }

        public ProductEntity DeserializeProduct(byte[] data)
        {
            ProductEntity result = new ProductEntity();

            using (MemoryStream m = new MemoryStream(data))
            {
                using (BinaryReader reader = new BinaryReader(m))
                {
                    byte[] guidBytes = reader.ReadBytes(16); // Guid is 16 bytes
                    result.Id = new Guid(guidBytes);

                    result.Name = reader.ReadString();
                    result.Description = reader.ReadString();
                    result.Price = reader.ReadDecimal();

                    byte[]? guidBytes2 = reader.ReadBytes(16); // Guid is 16 bytes
                    result.SupplierId = new Guid(guidBytes2);
                }
            }
            return result;
        }
    }

    class Program
    {
        public static HttpClient client = new HttpClient();
        public JsonSerializerOptions? options = null;

        static void Main()
        {
            var formatters = new List<MediaTypeFormatter>() {
                new JsonMediaTypeFormatter(),
                new XmlMediaTypeFormatter()
            };

            // resp.Content.ReadAsAsync<IEnumerable<ProductEntity>>(formatters);

            client.BaseAddress = new Uri("https://localhost:44378/");

            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));

            ProductEntity entity = new ProductEntity();

            entity.Id = new Guid("8e456581-b5f3-4680-91fe-de2409268a6d");
            entity.Name = "test prod  working";
            entity.Description = " Product Description  Test";
            entity.Price = 100;
            entity.SupplierId = new Guid("00000002-0000-0000-0000-000000000000");
            entity.CreatedBy = "Tatiana Golova";
            entity.CreatedDate = DateTime.Now;  
            entity.LastModifiedBy = "Diana Gontcharova";
            entity.LastModifiedDate = DateTime.Now;

            string? path = "api/v3/cachemediator/GetAllProducts";

            // var resultList = GetAllProductsAsync(path);
            var ret = AddEntityToCache(entity);

            async Task<List<ProductEntity>> GetAllProductsAsync(string? path)  
            {
                List<ProductEntity> products = new List<ProductEntity>();

                HttpResponseMessage response = await client.GetAsync(path);

                if (response.IsSuccessStatusCode)
                {
                    products = await response.Content.ReadAsAsync<List<ProductEntity>>();
                }
                return products;
            }

            async Task<bool> AddEntityToCache(ProductEntity product)
            {
                Debug.WriteLine("Entered Worker");

                HttpResponseMessage response = await client.PutAsJsonAsync<ProductEntity>(
                    "api/v3/cachemediator/AddEntityToCache", product);

                // response.EnsureSuccessStatusCode();

                return true;
            }

        }
    }
}