﻿using CacheAggregator.Application.Contracts.Persistence;
using CacheAggregator.Domain.Entities;
using MediatR;
using Microsoft.Extensions.Caching.Hybrid;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CacheAggregator.Application.Features.Products.Queries
{
    public class RemoveItemFromCacheQuery : IRequest<bool>
    {
        public required string id { get; set; } = string.Empty;  // _cacheKey = GUID as string
        public required string name { get; set; } = string.Empty;  //  = "products", for example
        public CancellationToken token { get; set; } = default;
    }
}