﻿
using CacheAggregator.Domain.Entities;
using AutoMapper;
using Microsoft.Extensions.Logging;
using CacheAggregator.Application.Contracts.Persistence;
using Microsoft.Extensions.Caching.Hybrid;
using MediatR;
using CacheAggregator.Application.Features;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Http;
using System.Net.Sockets;
using System.Diagnostics;

namespace CacheAggregator.Application.Contracts.Persistence
{
    public class ProductServiceHybrid(AppDbContext context, HybridCache cache) : IProductRepository
    {
        public readonly bool? optimisticBehaviour = true; // Cache Only! : No Database Action -> "Cache or Nothing" is Default
        public HybridCacheEntryOptions? cacheOptions;
       
        private object locker = 1;

        public static int executions { get; set; } = 0;
        public static int misses { get; set; } = 0;

        #region utility_functions
            #pragma warning disable CS8602
            public Type GetTypeForRecord<T>(T record)
            {
                var type = typeof(T);
                if (type == typeof(object))
                {
                    type = record.GetType();
                }
                return type;
            }
            #pragma warning restore CS8602
        #endregion

        public Task<List<ProductEntity>> CreateInitialCacheData(int nbrLines)
        {  
            List <ProductEntity> listProducts = new List<ProductEntity>();
            ProductEntity productEntity = new ProductEntity();

            for (int i = 0; i < 10; i++)
            {
                productEntity.Id = Guid.NewGuid();
                productEntity.Name = "product-" + i.ToString();
                productEntity.Price = (i * 2) + 50;
                productEntity.Description = "Product Description";

                Guid x = new Guid("00000002-0000-0000-0000-000000000000");

                productEntity.SupplierId = x;

                // from Base
                productEntity.CreatedBy = "Tatiana Golova";
                productEntity.CreatedDate = DateTime.Now.AddDays(-4);
                productEntity.LastModifiedBy = "Diana Gontcharova";
                productEntity.LastModifiedDate = DateTime.Now; 

                listProducts.Add(productEntity);

                productEntity = new ProductEntity();
            }
            executions++;
            return Task.FromResult(listProducts);
        }

        // Push some Random Sample Data to the Cache Overwites Existing Data 
        public async Task<bool> PushInitialProductDataToCache(List<ProductEntity> productData, HybridCache cache, CancellationToken cancellationToken = default)
        {
            var cStatus = cache.GetType();
            string cacheKey = "products";
            executions++;

            try
            {
                await cache.SetAsync(
                    cacheKey,
                    productData,
                    new HybridCacheEntryOptions
                    {
                        Expiration = TimeSpan.FromMinutes(60), // Set expiration
                        LocalCacheExpiration = TimeSpan.FromMinutes(60), // L1 expiration
                    }, null,
                    cancellationToken
                );
            }
            catch(Exception)
            {
                misses++;
                return false;
            }
            return true;
        }

        /// <summary>
        /// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <param name="id" du type GUID></param>
        /// <param name="hybridCache"></param>
        /// <param name="appDbContext"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        // Get One Unique Item from Cache (or from backing store if not in cache and backing store configured)
        public async Task<ProductEntity> GetProductById(string id, HybridCache hybridCache, AppDbContext appDbContext, CancellationToken token = default)
        {
            executions++;
            var cacheKey = $"product-" + id;

            // Use HybridCache to fetch data from either L1 or L2
            #pragma warning disable CS8603 // Possible null reference return.
            return await cache.GetOrCreateAsync(
                cacheKey,
                async token => await FetchProductFromDatabase(cacheKey, token),
                new HybridCacheEntryOptions
                {
                    Expiration = TimeSpan.FromMinutes(30), // Shared expiration for L1 and L2
                    LocalCacheExpiration = TimeSpan.FromMinutes(10) // L1 expiration
                }, null,
                CancellationToken.None
            );
            #pragma warning restore CS8603 // Possible null reference return.
        }
        
        public Task<ProductEntity?> FetchProductFromDatabase(string cacheKey, CancellationToken cancellationToken)
        {
            ProductEntity? product = null;

            if (optimisticBehaviour == false)
            {
                var tmp = cacheKey.Replace("product-", null);
                var realGuid = new Guid(tmp);

                product = context.Products.FirstOrDefault(p => p.Id == realGuid);

                Debug.WriteLine("Miss!");
                misses++;
            }

            if (optimisticBehaviour == true)
            {
                misses++;
                return Task.FromResult(product);    
            }
            return Task.FromResult(product);    
        }
        /// ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        /// <summary>
        /// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <param name="hybridCache"></param>
        /// <param name="appDbContext"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        // Get All Data Currently in Cache (via callback)
        public async Task<List<ProductEntity>> GetAllProducts(HybridCache hybridCache, AppDbContext appDbContext, CancellationToken token = default)
        {
            executions++;
            var cacheKey = "products";

            // Use HybridCache to fetch data from either L1 or L2
            return await cache.GetOrCreateAsync(
                cacheKey,
                async token => await FetchProductsFromDatabaseAsync(cacheKey, token),
                new HybridCacheEntryOptions
                {
                    Expiration = TimeSpan.FromMinutes(30), // Shared expiration for L1 and L2
                    LocalCacheExpiration = TimeSpan.FromMinutes(10) // L1 expiration
                }, null,
                CancellationToken.None
            );
        }
        public async Task<List<ProductEntity>> FetchProductsFromDatabaseAsync(string cacheKey, CancellationToken cancellationToken) 
        {
            List<ProductEntity> products = new List<ProductEntity>();
            
            if (optimisticBehaviour == false)
            {
                products = await context.Products.ToListAsync();
                Debug.WriteLine("Miss!");
                misses++;
                return products;
            }

            if (optimisticBehaviour == true)
            {
                misses++;
                return products;
            }
            return products;
        }
        /// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        public async Task<bool> AddProductToCache(string id, ProductEntity product, HybridCache hybridCache, CancellationToken token = default)
        {
            executions++;
            try
            {
                await hybridCache.SetAsync(
                                    $"product-{id}",
                                    product

                );
            }
            catch (Exception)
            {
                misses++;
                return false;
            }
            return true;
        }

        public async Task<bool> RemoveItemFromCache(string id, HybridCache hybridCache, CancellationToken token = default)
        {
            executions++;
            try
            {
                await hybridCache.RemoveAsync(
                                    $"product-{id}",
                                    token

                );
            }
            catch (Exception)
            {
                misses++;
                return false;
            }
            return true;
        }

        public string GetStats()
        {
            if (executions >= 1) 
            {
                double Executions = executions;
                double Misses = misses;
                string  Ratio  = "";

                Ratio = Math.Round(((Executions - Misses)/Executions) * 100, 2).ToString();

                string stats = string.Format("Total Transactions = {0} Total Hits = {1}  Total Misses = {2} Hit Rate % = {3} ",
                                             executions, executions-misses, misses, Ratio);
                return stats;
            }
            return "No Valid Stats";
        }
    }
}
