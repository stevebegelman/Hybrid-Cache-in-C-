﻿using Candriam.Shared.Contract.Repository;

using CacheAggregator.Domain.Entities;
using CacheAggregator.Application.Features;

using Microsoft.Extensions.Caching.Hybrid;
using System.Threading;

namespace CacheAggregator.Application.Contracts.Persistence
{
    public interface IProductRepository 
    {
        Task<List<ProductEntity>> CreateInitialCacheData(int nbrLines);  // Simulate [<<<Mock>>>] Product Data Creation from MQ-Series for Cache Initialisation

        Task<bool> PushInitialProductDataToCache(List<ProductEntity> productData, HybridCache hybridCache, CancellationToken token = default);  // Push new mocked Product Data Set to Cache

        Task<List<ProductEntity>> GetAllProducts(HybridCache hybridCache, AppDbContext appDbContext, CancellationToken token = default);  // GetAllProducts

        Task<ProductEntity> GetProductById(string _cacheKey, HybridCache hybridCache, AppDbContext appDbContext, CancellationToken token = default);  // Read a Product from the Cache by Id

        Task<bool> AddProductToCache(string _cacheKey, ProductEntity product, HybridCache hybridCache, CancellationToken token = default);  // Add a Product to Cache

        Task<bool> RemoveItemFromCache(string _cacheKey, HybridCache hybridCache, CancellationToken token = default);  // Remove an Item  from Cache
        
        // TODO : Move to Global, Shared Space & Log
        string GetStats();  //  Get Execution Stats on this Cache Cache (Volatile)

    }
}

