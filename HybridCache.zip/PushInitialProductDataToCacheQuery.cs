﻿using CacheAggregator.Application.Contracts.Persistence;
using CacheAggregator.Domain.Entities;

using MediatR;
using Microsoft.Extensions.Caching.Hybrid;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CacheAggregator.Application.Features.Products.Queries
{
    public class PushInitialProductDataToCacheQuery : IRequest<bool>
    {
        public required List<ProductEntity> productData { get; set; }
    }
}
