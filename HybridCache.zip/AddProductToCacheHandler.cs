﻿using CacheAggregator.Application.Contracts.Persistence;
using CacheAggregator.Domain.Entities;
using MediatR;
using Microsoft.Extensions.Caching.Hybrid;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CacheAggregator.Application.Features.Products.Queries
{
    public class AddProductToCacheHandler : IRequestHandler<AddProductToCacheQuery, bool>
    {
        private readonly HybridCache _cache;
        private readonly AppDbContext _context;

        public AddProductToCacheHandler(HybridCache cache, AppDbContext context)
        {
            _cache = cache;
            _context = context;
        }

        public async Task<bool> Handle(AddProductToCacheQuery request, CancellationToken token = default)
        {
            StatUtility.executions++;
            try
            {
                await _cache.SetAsync(
                                    $"product-{request.id}",
                                    request.productData

                );
            }
            catch (Exception)
            {
                StatUtility.misses++;
                return false;
            }
            return true;
        }

    }
}
