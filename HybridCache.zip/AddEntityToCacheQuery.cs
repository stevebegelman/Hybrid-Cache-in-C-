﻿using CacheAggregator.Application.Contracts.Persistence;
using CacheAggregator.Domain.Entities;
using MediatR;
using Microsoft.Extensions.Caching.Hybrid;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CacheAggregator.Application.Features.Products.Queries
{
    public class AddEntityToCacheQuery : IRequest<bool>
    {
        public  string id { get; set; } = string.Empty;  // _cacheKey = GUID(or Number)  as string
        public  string cacheName { get; set; } = string.Empty;  // for example "product" = "cache name"
        public required Object objectData { get; set; }
    }
}
