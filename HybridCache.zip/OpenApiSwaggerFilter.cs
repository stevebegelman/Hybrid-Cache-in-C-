﻿using System.Text.RegularExpressions;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace CacheAggregator.Api.Helper
{
    /// <summary>
    /// OpenApi Swagger Filter
    /// </summary>
    public class OpenApiSwaggerFilter:IDocumentFilter
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="httpContextAccessor"></param>
        public OpenApiSwaggerFilter(IHttpContextAccessor httpContextAccessor)
        {
                _httpContextAccessor = httpContextAccessor;
        }
        /// <summary>
        /// Apply Method
        /// </summary>
        /// <param name="swaggerDoc"></param>
        /// <param name="context"></param>
        public void Apply(OpenApiDocument swaggerDoc, DocumentFilterContext context)
        {
            string url = string.Empty;
            var request = _httpContextAccessor.HttpContext?.Request;
            if (request != null)
            {
                var versionPath = $"/api/{swaggerDoc.Info.Version}";
                url = $"{request.Scheme}://{request.Host}{request.PathBase}{versionPath}";

                var copy = new OpenApiPaths();
                foreach (var path in swaggerDoc.Paths)
                {
                    var newKey = Regex.Replace(path.Key, "/api/v[^/]*", string.Empty);
                    copy.Add(newKey, path.Value);
                }

                swaggerDoc.Paths.Clear();
                swaggerDoc.Paths = copy;
            }
            swaggerDoc.Servers.Clear();
            swaggerDoc.Servers.Add(new OpenApiServer { Url = url });
        }
    }
}
