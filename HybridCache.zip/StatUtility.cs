﻿
using CacheAggregator.Domain.Entities;
using AutoMapper;
using Microsoft.Extensions.Logging;
using CacheAggregator.Application.Contracts.Persistence;
using Microsoft.Extensions.Caching.Hybrid;
using MediatR;
using CacheAggregator.Application.Features;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Http;
using System.Net.Sockets;

namespace CacheAggregator.Application.Contracts.Persistence
{
    public class StatUtility
    {
        private object locker = 1;  // unused
        public static int executions { get;  set; } = 0;
        public static int misses { get;  set; } = 0;

        // Behaviour:  Set database behavour on all Web Servces: Candriam default should be 'true'
        public static bool? optimisticBehaviour { get; set; } = true;

        #region utility_functions
        #pragma warning disable CS8602
        public Type GetTypeForRecord<T>(T record)
                {
                    var type = typeof(T);
                    if (type == typeof(object))
                    {
                        type = record.GetType();
                    }
                    return type;
                }
        #pragma warning restore CS8602
        #endregion
    }
}
