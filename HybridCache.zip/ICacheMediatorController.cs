﻿using CacheAggregator.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CacheAggregator.Api.Controllers.V1
{
    public interface ICacheMediatorController
    {
        Task<bool> AddProductToCache(ProductEntity product);
        Task<bool> AddEntityToCache<T>(T myEntity) where T : class;    // Generic
        Task<List<ProductEntity>> CreateInitialCacheData();
        Task<List<ProductEntity>> GetAllProducts();
        Task<ProductEntity> GetProductById(string _cacheKey);
        Task<string> GetStats();
        Task<bool> PushInitialProductDataToCache();
        Task<bool> RemoveItemFromCache(string Name, string Id);      // Generic 
    }
}